<?php

$baseUrl = "http://localhost/php-project/terminplanner-pro/";
